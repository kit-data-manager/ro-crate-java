COVID-19: variation analysis reporting
--------------------------------------

This workflow takes VCF datasets of variants produced by any of the variant
calling workflows in
https://github.com/galaxyproject/iwc/tree/main/workflows/sars-cov-2-variant-calling
and generates tabular reports of variants by samples and by variant, along with
an overview plot of variants and their allele-frequencies across all samples.
